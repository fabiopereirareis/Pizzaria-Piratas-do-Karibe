package com.portifolio.pizzariappk;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PizzariaPpkApplication {

	public static void main(String[] args) {
		SpringApplication.run(PizzariaPpkApplication.class, args);
	}

}
