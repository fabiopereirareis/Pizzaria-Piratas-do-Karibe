package com.portifolio.pizzariappk.dto;

public class ContactDTO {

    private Long id_contact;
    private String number;
    private String type; // mudar para enum
}
