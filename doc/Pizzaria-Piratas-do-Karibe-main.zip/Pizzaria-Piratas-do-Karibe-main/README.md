# Pizzaria-Piratas-do-Karibe
Sistema de planos mensais para Pizzaria: Piratas do Karibe

Tecnologias usadas:

- Back-end:
  - Spring Boot 2.5.4 com Gradle
  - Java 11



